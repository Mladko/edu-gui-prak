package WineCalc;

import javax.swing.*;
import java.awt.*;

/**
 * Class description
 * @version 0.01a 16 Oct 2012
 * @author Benjamin Schuermann <dev+edu@schuermann.cc>
 */

public class Histogram extends JPanel {

    /** histogram's x position */
    private int x;

    /** histogram's y position */
    private int y;

    /** histogram width */
    private int w;

    /** histogram height */
    private int h;

    /**
     * Documentation comment
     *
     * @param x histogram's x position
     * @param y histogram's y position
     * @param w histogram's width
     * @param h histogram's height
     */
    public Histogram(int x, int y, int w, int h) {

        super();
        this.setHistogramProperties(x, y, w, h);

    }

    /**
     * Documentation comment
     *
     * @param x histogram's x position
     * @param y histogram's y position
     * @param w histogram's width
     * @param h histogram's height
     */
    public void setHistogramProperties(int x, int y, int w, int h) {

        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;

    }

    public void paintComponent(Graphics2D g) {

        super.paintComponent(g);
        g.drawRect(this.x, this.y, this.w, this.h);

    }

}
