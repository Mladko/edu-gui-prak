package WineCalc;

import javax.swing.*;
import java.awt.*;

/**
 * Class description
 * @version 0.01a 16 Oct 2012
 * @author Benjamin Schuermann <dev+edu@schuermann.cc>
 */

public class WineCalcUI extends JFrame {

    /** window's title */
    private String title;

    /** window's x position */
    private int x;

    /** window's y position */
    private int y;

    /** window's width */
    private int w;

    /** window's height */
    private int h; 

    /**
     * Documentation comment
     *
     * @param title window title
     * @param x window's x position
     * @param y window's y position
     * @param w window's width
     * @param h window's height
     */
    public WineCalcUI(String title, int x, int y, int w, int h) {
       
        super();

        /* setup a new window */
        this.setWindowProperties(title, x, y, w, h);
        this.setTitle(this.title);
        this.setBounds(this.x, this.y, this.w, this.h);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

    /**
     * Documentation comment
     *
     * @param title window title
     * @param x window's x position
     * @param y window's y position
     * @param w window's width
     * @param h window's height
     */
    public void setWindowProperties(String title, int x, int y, int w, int h) {

        this.title = title;
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;

    }

    /**
     * Documentation comment
     */
    public void drawHistogram() {

        /* set histogram size */
        int w = (this.w * 80 / 100);
        int h = (this.h * 25 / 100);

    }

    /**
     * Documentation comment
     */
    public void drawMapLlegend() {

        /* set size of map legend */
        int w = (this.w * 80 / 100);
        int h = (this.h * 45 / 100);

    }

}
