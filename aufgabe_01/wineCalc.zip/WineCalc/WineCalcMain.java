package WineCalc;

import javax.swing.*;
import java.awt.*;

/**
 * Class description
 * @version 0.01a 16 Oct 2012
 * @author Benjamin Schuermann <dev+edu@schuermann.cc>
 */

public class WineCalcMain {

    /**
     * Documentation comment
     */
    public static void main(String[] args) {

        /* set window properties */
        String title = "Trinkreife";
        int x = 20;
        int y = 20;
        int w = 800;
        int h = 600;

        /* set Histogram properties */
        int xHist = (x * 10 / 100);
        int yHist = (y * 10 / 100);
        int wHist = (w * 80 / 100);
        int hHist = (h * 25 / 100);

        /* create new window */
        JFrame f = new WineCalcUI(title, x, y, w, h);
        /* create new Histogram */
        f.setContentPane(new Histogram(xHist, yHist, wHist, hHist));
        /* display the new window */
        f.setVisible(true);   

    }

}
