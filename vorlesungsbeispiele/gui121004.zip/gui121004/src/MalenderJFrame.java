
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.JPanel;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author amh
 */
public class MalenderJFrame extends JFrame {

    class RectJPanel extends JPanel {

        private int x, y, w, h;

        RectJPanel(int x, int y, int w, int h) {
            super();
            this.setRect(x, y, w, h);
        }

        void setRect(int x, int y, int w, int h) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.repaint();
        }

        @Override
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawRect(x, y, w, h);
        }
    }
    
    RectJPanel rp = new RectJPanel(10, 20, 30, 40);

    MalenderJFrame() {
        super();
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setBounds(100, 150, 500, 250);
        this.setTitle("Fenster mit Rechteck");
        this.getContentPane().add(rp);
    }

    public static void main(String[] args) {
        MalenderJFrame mjf = new MalenderJFrame();
        mjf.setVisible(true);
    }
}
