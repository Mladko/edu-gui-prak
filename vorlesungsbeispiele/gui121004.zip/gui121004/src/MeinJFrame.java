
import javax.swing.JFrame;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author amh
 */
public class MeinJFrame extends JFrame {

    MeinJFrame() {
        super();
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setBounds(100, 150, 500, 250);
        this.setTitle("Mein erstes Fenster");
    }

    public static void main(String[] args) {
        MeinJFrame mjf = new MeinJFrame();
        mjf.setVisible(true);
    }
}
